import { useState, useEffect, useLayoutEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ACID, PURPLE, BG } from "../layout/Layout";
import { getStreamUrl } from "../core/GoogleDriveService";
import { AudioVisualizer } from "./AudioVisualizer";
import { DropComposeModal } from "./DropsManager";
import { usePlayer } from "../core/PlayerContext";

// ─── DESIGN TOKENS (local) ───────────────────────────────────
const FONT_MONO = "'JetBrains Mono', 'Courier New', monospace";

const extractYouTubeId = (url) => {
  const match = url?.match(/(?:v=|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : null;
};

const getVibeConfig = (vibeId, VIBE_TAGS) =>
  VIBE_TAGS.find((v) => v.id === vibeId) ?? VIBE_TAGS[0];

// ─── WINAMP BUTTON ───────────────────────────────────────────
const WinampBtn = ({ label, onClick, active = false, color = ACID, title, size = "md" }) => (
  <motion.button
    whileTap={{ scale: 0.85 }}
    onClick={onClick}
    title={title}
    className={`rounded-sm flex items-center justify-center text-xs font-bold transition-all ${
      size === "sm" ? "w-7 h-7" : "w-8 h-8"
    }`}
    style={{
      background: active ? `${color}22` : "transparent",
      border: `1px solid ${active ? color + "66" : color + "22"}`,
      color: active ? color : color + "66",
      boxShadow: active ? `0 0 8px ${color}44` : "none",
    }}
  >
    {label}
  </motion.button>
);

// ─── WINAMP PLAYER ───────────────────────────────────────────
export const WinampPlayer = ({ tracks = [], onDropSend, VIBE_TAGS }) => {
  const {
    activeTrack: track, setActiveTrack,
    isPlaying: playing, setIsPlaying: setPlaying,
    localQueue: queue,
    loopMode, toggleLoopMode, shuffle, setShuffle,
    autoPlaySignal, syncStatus,
    audioRef, ytPlayerRef,
    isYouTube: isYouTubeCtx,
    skip,
    masterVolume, setMasterVolume,
    activeVibe,
  } = usePlayer();

  const ytPollingRef = useRef(null);
  const mountedRef   = useRef(false);
  const currentTRef  = useRef(0);
  const [progress, setProgress] = useState(0);
  const [volume,   setVolume]   = useState(masterVolume ?? 80);
  const [duration, setDuration] = useState(0);
  const [currentT, setCurrentT] = useState(0);
  const [showDrop,     setShowDrop]     = useState(false);
  const [shouldScroll, setShouldScroll] = useState(false);
  const titleRef = useRef(null);

  // BUG-19: acento sigue filtro activo; si "all", usa vibe del track
  const vibeConf  = getVibeConfig(
    (activeVibe && activeVibe !== "all") ? activeVibe : (track?.vibe ?? "all"),
    VIBE_TAGS
  );
  const isYouTube = track?.type === "youtube" || (!track?.type && track?.url);

  useEffect(() => {
    // BUG-10: no resetear isPlaying en montaje inicial (desync al volver de pestaña)
    if (!mountedRef.current) { mountedRef.current = true; return; }
    setPlaying(false);
    setProgress(0);
    setCurrentT(0);
    setDuration(0);
  }, [track?.id]);

  useEffect(() => {
    if (!autoPlaySignal || !track) return;
    const timer = setTimeout(() => {
      if (isYouTube) {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.playVideo === "function") {
          ytPlayerRef.current.playVideo();
        }
      } else {
        audioRef.current?.play().catch(() => {});
        setPlaying(true);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [autoPlaySignal]);

const skipDir = useCallback((dir) => {
if (dir === -1 && currentTRef.current >= 3) {
// >= 3s: ir al track anterior
skip(dir, tracks);
return;
}
if (dir === -1) {
// < 3s: reiniciar track actual
if (isYouTube) { ytPlayerRef.current?.seekTo(0, true); }
else if (audioRef.current) { audioRef.current.currentTime = 0; }
currentTRef.current = 0;
setCurrentT(0);
setProgress(0);
return;
}
skip(dir, tracks);
}, [skip, tracks, isYouTube]);

  // ── Polling YT — local, reactivo a isPlaying ──────────────
  useEffect(() => {
    if (!isYouTube) return;
    if (!playing) {
      if (ytPollingRef.current) { clearInterval(ytPollingRef.current); ytPollingRef.current = null; }
      return;
    }
    ytPollingRef.current = setInterval(() => {
      const p = ytPlayerRef.current;
      if (!p || typeof p.getCurrentTime !== "function") return;
        const ct  = p.getCurrentTime() || 0;
        const dur = p.getDuration()    || 0;
        currentTRef.current = ct;
        setCurrentT(ct);
      setDuration(dur);
      setProgress(dur > 0 ? (ct / dur) * 100 : 0);
    }, 500);
    return () => {
      if (ytPollingRef.current) { clearInterval(ytPollingRef.current); ytPollingRef.current = null; }
    };
  }, [playing, track?.id, isYouTube]);

  const togglePlay = () => {
    if (isYouTube) {
      if (!ytPlayerRef.current) return;
      if (playing) { ytPlayerRef.current.pauseVideo(); }
      else         { ytPlayerRef.current.playVideo();  }
    } else {
      if (!audioRef.current) return;
      if (playing) { audioRef.current.pause(); setPlaying(false); }
      else         { audioRef.current.play().catch(() => {}); setPlaying(true); }
    }
  };

  const seekTo = (pct) => {
    const targetTime = (pct / 100) * duration;
    if (isYouTube) {
      if (!ytPlayerRef.current || !duration) return;
      ytPlayerRef.current.seekTo(targetTime, true);
    } else {
      if (!audioRef.current || !duration) return;
      audioRef.current.currentTime = targetTime;
    }
// BUG-NUEVO-06: actualizar visual aunque esté en pausa
    currentTRef.current = targetTime;
    setCurrentT(targetTime);
    setProgress(pct);
  };

  const changeVolume = (v) => {
    setVolume(v);
    setMasterVolume?.(v);
    if (isYouTube) { if (ytPlayerRef.current) ytPlayerRef.current.setVolume(v); }
    else           { if (audioRef.current)    audioRef.current.volume = v / 100; }
  };

  // ── Suscripción a eventos del <audio> centralizado ───────────
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTimeUpdate = () => {
      currentTRef.current = audio.currentTime;
      setCurrentT(audio.currentTime);
      setDuration(audio.duration || 0);
      setProgress(audio.duration ? (audio.currentTime / audio.duration) * 100 : 0);
    };
    const onLoaded = () => setDuration(audio.duration || 0);
    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("loadedmetadata", onLoaded);
    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("loadedmetadata", onLoaded);
    };
  }, []);

  useEffect(() => {
    if (masterVolume == null) return;
    setVolume(masterVolume);
    if (isYouTube) { if (ytPlayerRef.current) ytPlayerRef.current.setVolume(masterVolume); }
    else           { if (audioRef.current)    audioRef.current.volume = masterVolume / 100; }
  }, [masterVolume]);

// BUG-29: scroll de título solo si el texto desborda el contenedor
useLayoutEffect(() => {
if (!titleRef.current) return;
const raf = requestAnimationFrame(() => {
if (!titleRef.current) return;
setShouldScroll(titleRef.current.scrollWidth > titleRef.current.offsetWidth);
});
return () => cancelAnimationFrame(raf);
}, [track?.id, track?.title]);

  const fmtTime = (s) => {
    if (!s || isNaN(s)) return "0:00";
    const m   = Math.floor(s / 60);
    const sec = Math.floor(s % 60).toString().padStart(2, "0");
    return `${m}:${sec}`;
  };

  const accentColor = vibeConf?.color ?? ACID;

  useEffect(() => {
    if (!("mediaSession" in navigator) || !track) return;
    const ytId = extractYouTubeId(track.url ?? "");
    const artwork = ytId
      ? [{ src: `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`, sizes: "480x360", type: "image/jpeg" }]
      : [];
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title ?? "Sin título", artist: track.artist ?? "", album: "el búnker", artwork,
    });
    navigator.mediaSession.setActionHandler("play", () => {
      if (isYouTube) { ytPlayerRef.current?.playVideo?.(); }
      else { audioRef.current?.play(); setPlaying(true); }
    });
    navigator.mediaSession.setActionHandler("pause", () => {
      if (isYouTube) { ytPlayerRef.current?.pauseVideo?.(); }
      else { audioRef.current?.pause(); setPlaying(false); }
    });
    navigator.mediaSession.setActionHandler("previoustrack", () => skipDir(-1));
    navigator.mediaSession.setActionHandler("nexttrack",     () => skipDir(1));
    return () => {
      ["play", "pause", "previoustrack", "nexttrack"].forEach((action) => {
        try { navigator.mediaSession.setActionHandler(action, null); } catch (_) {}
      });
    };
  }, [track?.id, playing, skip]);

  return (
    <motion.div
      className="relative rounded-sm overflow-hidden"
      style={{
        background: `linear-gradient(145deg, rgba(10,10,10,0.98) 0%, rgba(20,20,20,0.98) 100%)`,
        border: `1px solid ${accentColor}33`,
        boxShadow: `0 0 30px ${accentColor}11, inset 0 0 40px rgba(0,0,0,0.6)`,
        fontFamily: FONT_MONO,
      }}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
    >
      {/* div#yt-player-div y <audio> viven en PlayerProvider (ADR-004 Enmienda S21) */}

      {/* Title Bar */}
      <div
        className="flex items-center justify-between px-3 py-2"
        style={{
          background: `linear-gradient(90deg, ${accentColor}18 0%, transparent 100%)`,
          borderBottom: `1px solid ${accentColor}22`,
        }}
      >
        <div className="flex items-center gap-2">
          <motion.div
            animate={playing ? { opacity: [1, 0.3, 1] } : { opacity: 0.4 }}
            transition={{ duration: 0.8, repeat: playing ? Infinity : 0 }}
            className="w-1.5 h-1.5 rounded-full"
            style={{ background: accentColor, boxShadow: `0 0 6px ${accentColor}` }}
          />
          <span className="text-xs tracking-[0.3em] uppercase font-bold" style={{ color: accentColor }}>
            MUSIC LAB
          </span>
          {syncStatus === "syncing" && (
            <motion.span animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 0.9, repeat: Infinity }}
              className="text-xs" style={{ color: "#ffcc00", marginLeft: 2 }} title="Sincronizando cola...">◌</motion.span>
          )}
          {syncStatus === "error" && (
            <span className="text-xs" style={{ color: "#ff4444" }} title="Error guardando cola">✕</span>
          )}
        </div>
        <div className="flex gap-2">
          <span className="text-xs tracking-widest uppercase px-2 py-0.5 rounded-sm"
            style={{ color: accentColor, background: `${accentColor}15`, border: `1px solid ${accentColor}33` }}>
            {vibeConf?.icon} {vibeConf?.label}
          </span>
        </div>
      </div>

      {/* Visualizer */}
      <div className="px-3 pt-3 pb-1" style={{ background: "rgba(0,0,0,0.4)" }}>
        <AudioVisualizer audioRef={audioRef} isPlaying={playing} accentColor={accentColor} />
      </div>

      {/* Track Info */}
      <div className="px-3 py-2 overflow-hidden" style={{ background: "rgba(0,0,0,0.3)" }}>
        <div className="overflow-hidden whitespace-nowrap" style={{ width: "100%" }}>
          <motion.p
            ref={titleRef}
            animate={shouldScroll ? { x: ["0%", "-40%", "0%"] } : {}}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            className="text-sm font-bold inline-block"
            style={{ color: accentColor, textShadow: `0 0 10px ${accentColor}66` }}
          >
            {track ? `${track.title} — ${track.artist}` : "◈ SELECT A TRACK ◈"}
          </motion.p>
        </div>
        {track?.note && (
          <p className="text-xs mt-0.5 opacity-40 truncate" style={{ color: accentColor }}>↳ {track.note}</p>
        )}
      </div>

      {/* Seek Bar */}
      <div className="px-3 py-2">
        <div className="flex items-center gap-2">
          <span className="text-xs tabular-nums opacity-50" style={{ color: accentColor }}>{fmtTime(currentT)}</span>
          <div className="relative flex-1 h-2 group cursor-pointer" onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            seekTo(((e.clientX - rect.left) / rect.width) * 100);
          }}>
            <div className="absolute inset-0 rounded-full" style={{ background: `${accentColor}22` }} />
            <motion.div className="absolute top-0 left-0 h-full rounded-full"
              style={{ width: `${progress}%`, background: `linear-gradient(90deg, ${accentColor} 0%, ${accentColor}aa 100%)`, boxShadow: `0 0 8px ${accentColor}66` }} />
            <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full border-2 opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ left: `calc(${progress}% - 6px)`, borderColor: accentColor, background: BG, boxShadow: `0 0 8px ${accentColor}` }} />
          </div>
          <span className="text-xs tabular-nums opacity-50" style={{ color: accentColor }}>{fmtTime(duration)}</span>
        </div>  
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between px-3 pb-3">
        <div className="flex gap-2">
          <WinampBtn
            label={loopMode === "track" ? "⟳¹" : "⟳"}
            active={loopMode !== "off"}
            color={accentColor}
            onClick={toggleLoopMode}
            title={loopMode === "off" ? "Loop: off" : loopMode === "list" ? "Loop: lista" : "Loop: track"}
          />
          <WinampBtn label="⇄" active={shuffle} color={accentColor} onClick={() => setShuffle((p) => !p)} title="Shuffle" />
        </div>
        <div className="flex items-center gap-3">
          <WinampBtn label="◀◀" color={accentColor} onClick={() => skipDir(-1)} title="Prev" size="sm" />
          <motion.button whileTap={{ scale: 0.9 }} onClick={togglePlay}
            className="w-11 h-11 rounded-sm flex items-center justify-center text-lg font-bold transition-all"
            style={{ background: `${accentColor}22`, border: `2px solid ${accentColor}66`, color: accentColor,
              boxShadow: playing ? `0 0 16px ${accentColor}55` : "none", textShadow: `0 0 8px ${accentColor}` }}>
            {playing ? "⏸" : "▶"}
          </motion.button>
          <WinampBtn label="▶▶" color={accentColor} onClick={() => skipDir(1)} title="Next" size="sm" />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs opacity-40" style={{ color: accentColor }}>🔊</span>
          <input type="range" min={0} max={100} value={volume}
            onChange={(e) => changeVolume(Number(e.target.value))}
            className="w-14 h-1 appearance-none cursor-pointer rounded-full"
            style={{ background: `linear-gradient(90deg, ${accentColor} ${volume}%, ${accentColor}22 ${volume}%)`, accentColor }} />
        </div>
      </div>

      {/* Drop Button */}
      {track && (
        <motion.button whileTap={{ scale: 0.96 }} onClick={() => setShowDrop(true)}
          className="w-full py-2 text-xs tracking-[0.25em] uppercase font-bold transition-all"
          style={{ background: `linear-gradient(90deg, ${PURPLE}22 0%, ${PURPLE}11 100%)`,
            borderTop: `1px solid ${PURPLE}33`, color: PURPLE, textShadow: `0 0 8px ${PURPLE}88` }}>
          ⚡ LANZAR DROP
        </motion.button>
      )}

      <AnimatePresence>
        {showDrop && (
          <DropComposeModal track={track} onClose={() => setShowDrop(false)}
            currentMinute={currentT} trackDuration={duration}
            onSend={(dropData) => { onDropSend?.(dropData); setShowDrop(false); }} />
        )}
      </AnimatePresence>
    </motion.div>
  );
};